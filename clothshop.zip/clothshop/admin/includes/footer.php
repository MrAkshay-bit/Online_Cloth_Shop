<div class="footer">
            
            <div>
                <strong>Copyright &copy;</strong> Cloth Shop
            </div>
        </div>